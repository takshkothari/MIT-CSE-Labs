from django.apps import AppConfig


class formappConfig(AppConfig):
    name = 'formapp'
