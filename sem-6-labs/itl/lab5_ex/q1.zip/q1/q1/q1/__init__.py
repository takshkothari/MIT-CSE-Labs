"""
Package for q1.
"""
