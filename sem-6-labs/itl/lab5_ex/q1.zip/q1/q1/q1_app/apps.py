from django.apps import AppConfig


class q1_appConfig(AppConfig):
    name = 'q1_app'
