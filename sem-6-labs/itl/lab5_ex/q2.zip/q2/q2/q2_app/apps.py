from django.apps import AppConfig


class q2_appConfig(AppConfig):
    name = 'q2_app'
