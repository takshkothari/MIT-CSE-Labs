"""
Package for q2.
"""
